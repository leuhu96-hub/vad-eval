MINI CVAT VIDEO – GÁN NHÃN + ĐÁNH GIÁ GROUND TRUTH (bản chạy local)
=====================================================================

CÁCH CHẠY (Windows / macOS / Linux, không cần cài gì, không cần mạng)
  1. Giải nén cả thư mục (giữ nguyên thư mục lib/ cạnh index.html).
  2. Mở index.html bằng Chrome hoặc Edge (double-click, hoặc kéo file vào trình duyệt).
  3. Bấm "Mở video" và chọn video (MP4 H.264 hoặc WebM).

  Nếu trình duyệt chặn khi mở trực tiếp từ file, chạy một web server nhỏ trong thư mục này:
      python -m http.server 8000
  rồi mở http://localhost:8000

NỘI DUNG
  index.html              công cụ gán nhãn + nút "Đánh giá GT"
  lib/opencv.js           OpenCV.js 4.10 (Apache 2.0) – chỉ tải khi chạy Nhóm C
  lib/yunet_model.js      model YuNet 2026may (MIT), nhúng dạng base64
  sample/c1.webm          video thử (2 người, có cài sẵn lỗi GT)
  sample/c1_gt.json       nhãn của video thử -> bấm "Nhập", dán/chọn file này
  scripts/                analyze_gt.py, eval_face_postproc.py, make_test_video.py (bản Python)

ĐỊNH DẠNG GT ĐƯỢC HỖ TRỢ
  - Nhập vào công cụ: CVAT for video 1.1 (.xml/.zip), Mini CVAT JSON,
    XML Music Video dataset (<Video><Trajectory obj_id><Frame frame_no x y width height/>, giữ nguyên obj_id).
  - Xuất: CVAT XML, Mini CVAT JSON, MOT 1.1, Music Video XML, YOLO.
  - scripts/analyze_gt.py và eval_face_postproc.py đọc trực tiếp MOT hoặc Music Video XML
    (analyze_gt.py --save-mot để chuyển XML sang MOT).

THỬ NHANH VỚI DỮ LIỆU MẪU
  1. Mở video sample/c1.webm, đặt FPS = 25.
  2. Bấm "Nhập" -> "Chọn file…" -> sample/c1_gt.json.
  3. Bấm "Đánh giá GT" -> Nhãn: face -> bật Nhóm C -> "Chạy phân tích".
     Kết quả đúng: mặt thiếu nhãn frame ~20–32, box vẽ vào nền frame ~80–88,
     (nếu chọn SFace) 2 cặp "cùng người nhưng 2 ID".

KIỂM TRA DANH TÍNH (cùng người 2 ID / 1 ID 2 người)
  Cần model SFace (38 MB, không kèm theo do dung lượng):
  tải face_recognition_sface_2021dec.onnx ở
  https://github.com/opencv/opencv_zoo/tree/main/models/face_recognition_sface
  rồi bấm "Chọn file .onnx…" trong hộp thoại Đánh giá GT.

BOX MODEL (hiển thị box model gán chồng lên GT) – mục "Box model" ở thanh bên
  - "Chạy frame này": YuNet chạy trên frame hiện tại. "Tự chạy…": chạy mỗi khi đổi frame.
  - "Nhập kết quả…": file MOT có score (frame,id,x,y,w,h,score[,10 landmark]), ví dụ raw.txt
    hoặc res/variant_*.txt của eval_face_postproc.py (tự gộp box trùng bằng NMS).
  - Màu: xanh = khớp GT · hồng "thừa" = model thấy, GT không có · vàng "model sót" = GT có, model không thấy.
  - "Thêm box chưa có nhãn → GT": biến box hồng ở frame này thành track mới. Phím B: ẩn/hiện.
  - Frame chưa chạy model thì giữ box của frame gần nhất trước đó, dời theo chuyển động (vẽ mờ,
    ghi "· ước lượng từ fN") để không bị nháy khi play.
  - "Tự chạy YuNet (tính trước)": một bản video ẩn chạy TRƯỚC đầu phát và detect các frame sắp tới,
    nên khi phát tới frame n thì box của n đã có sẵn (không trễ). Vạch xanh ở mép trên timeline =
    đoạn đã tính trước. Mẹo: dừng vài giây cho nó tính trước một đoạn rồi mới play.
    Máy chậm hơn video thì khi phát chỉ tính cách quãng (xem "ms/frame" ở mục Box model).
  - Detect chạy trong Web Worker để video không giật. Worker chỉ chạy khi mở qua web server
    (python -m http.server 8000); mở trực tiếp từ file vẫn chạy được nhưng có thể giật.

ĐÁNH GIÁ MODEL SO VỚI GT (cả video) – nút "Đánh giá model so với GT…" ở mục Box model
  - Nhập file kết quả của model (MOT có score, hoặc Music Video XML), mở GT, bấm nút -> "Tính".
  - Ra: Precision, Recall, F1, AP, mIoU, TP/FP/FN, % frame đúng hoàn toàn, recall theo cỡ mặt,
    bảng theo ngưỡng score (0.3–0.9), recall từng ID (kèm đoạn sót liền dài nhất), danh sách đoạn lỗi.
  - Cách ghép box giống dòng "0. baseline" của eval_face_postproc.py eval (cùng --thr), nên số khớp nhau.
  - Bấm một đoạn lỗi để nhảy tới; phím , / . đi tới đoạn lỗi trước / sau; vạch hồng trên timeline = frame lỗi.
  - "Tải CSV": từng frame lỗi (frame, frame_mot, n_gt, n_det, tp, fp, fn, ID bị sót).
  - Box từ YuNet trong trình duyệt: chỉ tính các frame model đã chạy.

PHÍM TẮT CHÍNH
  R vẽ box · F / D frame sau / trước (Shift: ±10) · O outside (mất / hiện lại)
  K keyframe · B ẩn/hiện box model · , / . đoạn model sai trước / sau · [ / ] nghi vấn GT trước / sau · Ctrl+Z hoàn tác · ? xem tất cả phím tắt

GHI CHÚ
  - Video và nhãn không rời khỏi máy: mọi xử lý chạy trong trình duyệt.
  - Nhãn tự lưu trong trình duyệt theo tên file video. Xoá dữ liệu trình duyệt sẽ mất,
    nên bấm "Xuất" định kỳ để sao lưu. Mở index.html ở thư mục khác = kho lưu khác.
  - Khi chạy offline, nút nén .zip (JSZip tải từ internet) không có: "Xuất" và
    "Tải báo cáo" sẽ tải từng file riêng.
  - Số frame trong công cụ đếm từ 0; file MOT xuất ra đếm từ 1.
